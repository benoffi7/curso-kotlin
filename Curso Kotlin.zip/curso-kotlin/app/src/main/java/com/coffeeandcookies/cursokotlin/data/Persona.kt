package com.coffeeandcookies.cursokotlin.data

data class Persona (
    var nombre:String,
    var edad:Int
)